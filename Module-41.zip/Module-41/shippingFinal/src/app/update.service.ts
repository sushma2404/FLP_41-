import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Delivery } from 'src/delivery';


@Injectable({
  providedIn: 'root'
})
export class UpdateService {

  prod:Observable<Delivery>;

  constructor(private httpClient:HttpClient) { }

  public proStatus(product_id):Observable<Delivery>
 {
   return this.httpClient.get<Delivery>("http://localhost:9090/get/"+product_id);
 }

}
